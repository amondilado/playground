import {html} from '@polymer/polymer/lib/utils/html-tag.js';

const template = html`
<dom-module id="datepicker-shared-styles">
<template>
    <style>
        :host {
            --adp-backdrop-bg: rgba(0,0,0,.2) default;
            --adp-btn: {
                background-color: var(--brand-primary);
                color: var(--bg-primary-color);
            }
        }
        #adpBackdrop {
            background-color: var(--adp-backdrop-bg, rgba(0,0,0,0));
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            display: none;
            z-index: 90;
        }
        app-datepicker {
            display: none;
            box-shadow: 0 2px 20px rgba(0,0,0,.2);
            position: absolute;
            top: 100%;
            left: 0;
            z-index: 100;
        }
        app-datepicker[open="true"] {
            display: block;
        }
        .btn {
            @apply --adp-btn;
        }
        .adp-item {
            position: relative;
        }
    </style>
</template>
</dom-module>`;
template.setAttribute('style', 'display: none;');
document.head.appendChild(template.content);