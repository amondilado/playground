/* TODO
* - Update date on input or placeholder
*/
import '@polymer/polymer/polymer-legacy.js';

/**
 * @polymerBehavior
*/
export const DatePickerBehavior = {
    properties: {
        inputDate: String,
        maxDate: String
    },

    _onSelectedDateChanged: function(e) {},
    formatted: function(v) {},
    _openDialog: function(t) {
        this._closeDialog();
        this.$.adpBackdrop.style.display = "block";
        t.setAttribute('open',true);
        t.nextSibling.setAttribute('open', 'true');
    },
    _closeDialog: function() {
        const dps = this.shadowRoot.querySelectorAll('app-datepicker');
        this.$.adpBackdrop.removeAttribute('style');

        dps[0].removeAttribute('open');
        dps[0].previousSibling.removeAttribute('open');

        if (dps.length === 2 ) {
            dps[1].removeAttribute('open');
            dps[1].previousSibling.removeAttribute('open');
        }
    },
    _toggleDialog: function(e) {
        var t = (e.target.type !== 'button') ? e.target.parentNode : e.target;
        (t.hasAttribute("open")) ? this._closeDialog() : this._openDialog(t);
    }
};