/* Adaptation of component app-datepicker https://www.webcomponents.org/element/motss/app-datepicker/elements/app-datepicker */
import '@polymer/polymer/polymer-legacy.js';
import {Polymer} from '@polymer/polymer/lib/legacy/polymer-fn.js';
import {html} from '@polymer/polymer/lib/utils/html-tag.js';
import '@polymer/polymer/lib/elements/dom-repeat.js';
import {DatePickerBehavior} from './datepicker-behavior.js';
import './app-datepicker.js';
import '../../assets/app-icons.js';
import './datepicker-shared-styles.js';

const template = html`
<dom-module id="datepicker-dropdown">
    <template strip-whitespace>
        <style include="datepicker-shared-styles"></style>
        
        <div id="adpBackdrop" on-click="_closeDialog"></div>
        <div id="dateTime1" class="adp-item">
            <button on-click="_toggleDialog" type="button" class="btn">
                <slot name="adp-icon1"></slot>
                Pickup: {{inputDate}}
            </button>
            <app-datepicker
                id="datepicker"
                format="yyyy-mm-dd"
                date="{{selectedDate_1}}"
                on-date-changed="_onSelectedDateChanged"
                input-date="{{inputDate}}"
                min-date="{{minDate}}"
                max-date="{{maxDate}}"
                auto-update-date="true"
                disable-days="{{disableDays}}"
                disable-dates="{{disableDates}}"
                no-animation></app-datepicker>
        </div>
    </template>`;
template.setAttribute('style', 'display: none;');
document.body.appendChild(template.content);

Polymer({
    is: 'datepicker-dropdown',
    behaviors: [DatePickerBehavior]
});
