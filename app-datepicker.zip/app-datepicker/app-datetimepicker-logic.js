/* TODO
 * - Set locales
 * - Notifications
 * - gotoToday
 * - range
 * - plugin https://scotch.io/tutorials/building-your-own-javascript-modal-plugin
 * - check date format
 * - check outofbounds and init Time ovalues onn has min duration
 */

var app,
    dp1,
    dp2,
    wcReady = dtpReady = !1;

var DateTimePicker = {
    equalDates: !1,
    initState: !0,
    dateFormat: "YYYY-MM-DD",
    tmin: 1,
    timeStart: "12:00",
    timeEnd: "12:00",
    minDuration: 0,
    disabledDates: []
};

DateTimePicker.today = DateTimePicker.inputDate = DateTimePicker.minDate = DateTimePicker.dateEnd = moment().utcOffset(120).format(DateTimePicker.dateFormat);

// console.log('DateTimePicker.timeStart', DateTimePicker.timeStart, 'DateTimePicker.timeEnd', DateTimePicker.timeEnd);

DateTimePicker.formatDates = function() {
    // Update equalDates
    this.equalDates = (dp1.date === dp2.date);
    // console.log('FORMATTED:\ndp1.inputDate: ',dp1.inputDate,' | dp1.date: ',dp1.date,' | dp1.minDate: ',dp1.minDate);
    // console.log('dp2.inputDate: ',dp2.inputDate,' | dp2.date: ',dp2.date,' | dp2.minDate: ',dp2.minDate);
    app.formattedDate_1 = app.formatted(dp1.date);
    app.formattedDate_2 = app.formatted(dp2.date);
};

DateTimePicker.init = function() {
    app = document.querySelector("app-datetime-picker");

    if(app.getAttribute('duration-min'))
        this.minDuration = parseInt(app.getAttribute('duration-min'));
    if(app.getAttribute('disabled-dates'))
        this.disabledDates = app.getAttribute('disabled-dates');
    if(app.getAttribute("input-date"))
        this.inputDate = app.getAttribute("input-date");

    // Time init values
    if(app.getAttribute('time-min'))
        this.tmin = parseInt(app.getAttribute('time-min'));
    if(app.getAttribute('time-start'))
        this.timeStart = app.getAttribute('time-start');
    if(app.getAttribute('time-end'))
        this.timeEnd = app.getAttribute('time-end');
};

DateTimePicker.setDisabledDates = function(arr) {
    for (var l = arr.length - 1; l >= 0; l--) {
        arr[l] = arr[l].replace(/-/g, '/');
    }
    app.disableDates = arr; // Pass an object or array in JSON format
};

DateTimePicker.disableStartPastHours = function(idx, items) {
    var i = idx - 1;

    do {
        items[i].setAttribute("disabled", true);
        i--;
    } while(0 <= i);
};

DateTimePicker.disableEndPastHours = function(idx, items) {
    console.log('__ disableDropoffPastHours idx: ', idx,'items.length: ',items.length);

    for (var j = items.length - 1; 0 <= j; j--) {
        if (j < idx) {
            items[j].setAttribute("disabled", true);
        } else {
            items[j].removeAttribute("disabled");
        }
    }
};

DateTimePicker.resetDisabledTimeValues = function(t1,t2) {
    // console.log('resetDisabledTimeValues', t1.length);
    for (let i = t2.length - 1; i >= 0; i--) {
        t1[i].removeAttribute('disabled');
        t2[i].removeAttribute('disabled');
    }
};

DateTimePicker.datetimepicker = function () {
    var _self = this, outOfBounds = !1;
    app = document.querySelector('app-datetime-picker');
    dp1 = app.$.dp1;
    dp2 = app.$.dp2;

    _self.equalDates = (dp1.date === dp2.date);

    var t1 = app.$.time1,
        t2 = app.$.time2,
        t_interval = parseInt(app.timeInterval),
        t_intervalH = app.intervalHours,
        // dateFormatComponent = "YYYY/MM/DD", // e.g. 2019/01/25
        // dateDisplayFormat = "L", // e.g. 25/12/2018
        minDdate, minDdateMin,
        d1_o1d = dp1.date,
        isToday = dp1.date === _self.today;

    console.log('isToday: ', isToday);

    // Init datepicker values
    app.disableDays = []; // Reset defaults. Pass an object or array in JSON format [moment().add(7, 'days').format(dateFormat), moment().add(8, 'days').format(dateFormat)];

    // Time
    var t1_items = app.getElements('plb_1'), // app.$.plb_1.childNodes, // app.$.plb_1.items: returns array of item value
        t2_items = app.getElements('plb_2'), // app.$.plb_2.childNodes
        tStart = {},
        tEnd = {},
        tNow = {
            time: { h: moment().utcOffset(120).format('kk'), m: moment().utcOffset(120).format('mm')},
            timeMin: { h: moment().utcOffset(120).add(_self.tmin, 'hours').format('kk'), m: moment().utcOffset(120).format('mm')}
        },
        temp,
        equal_or_min = _self.equalDates || !!(_self.minDuration);

    tNow.closest = calcClosestTime(tNow.time);
    tNow.index = t_intervalH.indexOf(tNow.closest);

    tStart.closest = calcClosestTime(tNow.time);
    tStart.selected = (isToday) ? tStart.closest : _self.timeStart;
    tStart.index = t_intervalH.indexOf(tStart.selected);
    temp = tStart.selected.split(':');
    tStart.h = temp[0];
    tStart.m = temp[1];
    tEnd.selected = _self.timeEnd;

    if (_self.equalDates || isToday) {
        tEnd.selected = moment({h: tStart.h, m: tStart.m}).add(_self.tmin, 'hours').format('kk:mm');
        console.log('> equalDates || isToday >>  tEnd.selected: ',tEnd.selected);
    }
    tEnd.index = t_intervalH.indexOf(tEnd.selected);

    console.log('tNow: ',tNow,'\ntStart: ',tStart,'\ntEnd: ',tEnd);

    function updateCurrentTime() {
        tNow = {
            time: { h: moment().utcOffset(120).format('kk'), m: moment().utcOffset(120).format('mm')},
            timeMin: { h: moment().utcOffset(120).add(_self.tmin, 'hours').format('kk'), m: moment().utcOffset(120).format('mm')}
        };
        tNow.closest = calcClosestTime(tNow.time);
        tNow.index = t_intervalH.indexOf(tNow.closest);
    }

    //_applySelection (applies on iron-selectable item) must be called after _setSelectedItem
    function updateStartTime(val) {
        app.selectedTime_1 = val;
        t1._applySelection;
    }

    function updateEndTime(val) {
        app.selectedTime_2 = val;
        t2._applySelection;
    }

    function enableTimeEndValues() {
        console.log('_______________ enableTimeEndValues: ',t2_items.length);
        var t2 = app.getElements('plb_2');
        for (let i = t2_items.length - 1; i >= 0; i--) {
            t2_items[i].removeAttribute('disabled');
        }
    }

    function setOutOfBounds() {
        alert("OUT OFF BOUNDS! Please select the next available date in your dropoff calendar.");
        outOfBounds = !0;
        d1_o1d = 0;
        enableTimeEndValues();
        dp2.minDate = dp2.inputDate;
        dp2.inputDate = moment(dp2.inputDate).add(1,'day').format(_self.dateFormat);
        dp2.enforceDateChange();
        _self.formatDates();
    }

    function initTime() {
        console.log('@@@# initTime \nisToday: ', isToday,'tNow: ',tNow,'\ntStart: ',tStart,'\ntEnd: ',tEnd);

        if (isToday) {
            _self.disableStartPastHours(tStart.index, t1_items);
            _self.disableEndPastHours(tEnd.index, t2_items);
        }

        updateStartTime(tStart.index);
        updateEndTime(tEnd.index);
    }

    function updateMinTime() {
        // Update current time
        updateCurrentTime();

        if(typeof tStart.index === 'undefined') {
            tStart.closest = calcClosestTime(tNow.time);
            tStart.closestIndex = t_intervalH.indexOf(tStart.closest);
            tStart.selected = (isToday) ? tStart.closest : _self.timeStart;
            tStart.index = t_intervalH.indexOf(tStart.selected);
        } else {
            tStart.selected = t_intervalH[tStart.index];
        }
        temp = tStart.selected.split(':');
        tStart.h = temp[0];
        tStart.m = temp[1];

        console.log('equal_or_min: ',equal_or_min, '_self.equalDates: ',_self.equalDates,' temp: ',temp,' tStart.h: ',tStart.h, ' tStart.m: ',tStart.m);

        if (equal_or_min) {
            tEnd.tmin = moment({h: tStart.h, m: tStart.m}).add(_self.tmin, 'hours').format('kk:mm');
        }

        tEnd.tminIndex = t_intervalH.indexOf(tEnd.tmin);

        if(isToday && !_self.minDuration) {
            tEnd.closest = calcClosestTime(tNow.closest);
        }

        tEnd.closest = tEnd.tmin;
        tEnd.selected = tEnd.closest; //(typeof tEnd.selected !== 'undefined' && isToday || _self.equalDates) ? tEnd.closest : _self.timeEnd;
        tEnd.index = t_intervalH.indexOf(tEnd.selected);

        console.log('isToday: ', isToday, ' tNow.time: ', tNow.time, '\ntStart.closest: ', tStart.closest,' tStart.selected: ', tStart.selected,' | tStart.index: ', tStart.index,
            '\ntEnd.tminIndex: ',tEnd.tminIndex,' tEnd.tmin: ',tEnd.tmin,' tEnd.closest: ',tEnd.closest,' | tEnd.selected: ', tEnd.selected,' | tEnd.index: ', tEnd.index);

        // Update t1
        if(isToday && tStart.index <= tNow.index) {
            updateStartTime(tNow.index);
        }

        // Update t2
        if(equal_or_min) { // TODO Add if d2 = d1 + minDuration
            if(tEnd.tminIndex >= tEnd.index) {
                // d2recalc =  moment(dp1.date).add(_self.minDuration, 'days').format(_self.dateFormat);
                // console.log('--->>>> d2recalc', d2recalc);
                // OutOf bounds
                var oob_offset = (t_interval > 1) ? (t_interval == 15) ? _self.tmin * 4 : _self.tmin * 2 : 1;
                console.log('t1_items.length - oob_offset = ', t1_items.length - oob_offset, 't1_items.length: ',t1_items.length,' oob_offset: ',oob_offset);
                if (isToday || dp2.date === d2recalc) {
                    if(parseInt(tStart.index) >= parseInt(t1_items.length - oob_offset)) {
                        setOutOfBounds();
                        return;
                    }
                }
                if(!isToday && moment(dp2.date).isBefore(d2recalc)) {
                    console.log('>>>> equal_or_min not today');
                    app.selectedTime_2 = null;
                    tEnd.index = calcTimeIndexOffset();
                    console.log('tEnd.index: ',tEnd.index);
                    var t2_newItem = t2_items[tEnd.index], t2_newIdx = t2_newItem.getAttribute("index");
                    // console.log('t2_newItem: ',t2_newItem,' t2_newIdx: ',t2_newIdx);
                    updateEndTime(t2_newIdx);
                }
            }
        }

        // Update t1 & t2
        if(isToday && tEnd.tminIndex >= tStart.index) {
            console.log('Update t1 & t2');
            updateStartTime(tStart.index);
            updateEndTime(tEnd.index);

            console.log('tNow: ',tNow,'\ntStart: ',tStart,'\ntEnd: ',tEnd);
        }
    }

    function initDates() {
        console.log('------INIT DATES:\ndp1.inputDate: ',dp1.inputDate,' = dp1.date: ',dp1.date,' | dp1.minDate: ',dp1.minDate);
        console.log('dp2.inputDate: ',dp2.inputDate,' | dp2.date: ',dp2.date,' | dp2.minDate: ',dp2.minDate,' | minDuration: ',_self.minDuration);

        dp1.minDate = moment().subtract(1, "day").format(_self.dateFormat);
        if (moment().isAfter(dp1.date)) {
            dp1.inputDate = _self.today;
            dp1.enforceDateChange();
        }

        minDdate = getMinDurationDate();
        minDdateMin = moment(minDdate).subtract(1,'day').format(_self.dateFormat);
        console.log('minDdate: ',minDdate,' | minDdateMin: ',minDdateMin,' | minDuration: ',_self.minDuration,'\n------');

        updateEndDate(minDdate);
        _self.formatDates();

        initTime();

        _self.initState = !1;

        // console.log('AFTER :\ndp1.inputDate: ',dp1.inputDate,' = dp1.date: ',dp1.date,' | dp1.minDate: ',dp1.minDate);
        // console.log('dp2.inputDate: ',dp2.inputDate,' | dp2.date: ',dp2.date,' | dp2.minDate: ',dp2.minDate,' | minDuration: ',_self.minDuration);
    }

    function getMinDurationDate() {
        return moment(dp1.date).add(_self.minDuration, 'days').format(_self.dateFormat);
    }

    function updateEndDate(date) {
        dp2.inputDate = date;
        dp2.minDate = moment(date).subtract(1, "day").format(_self.dateFormat);
        dp2.enforceDateChange();
    }

    function updateMinDate() {
        console.log('UPDATE_DATE_MIN:\ndp1.inputDate: ',dp1.inputDate,' | dp1.date: ',dp1.date,' | dp1.minDate: ',dp1.minDate);
        console.log('dp2.inputDate: ',dp2.inputDate,' | dp2.date: ',dp2.date,' | dp2.minDate: ',dp2.minDate);

        if(!moment(d1_o1d).isSame(dp1.date)) {
            d1_o1d = dp1.date;
            d2recalc =  moment(dp1.date).add(_self.minDuration, 'days').format(_self.dateFormat);
            d2recalcmin = moment(d2recalc).subtract(1,'day').format(_self.dateFormat);

            console.log('--> d1_o1d: ',d1_o1d,' | d2recalc: ',d2recalc,' | d2recalcmin: ',d2recalcmin,' | minDuration: ',_self.minDuration);

            if (moment(dp1.date).isAfter(d2recalc) || moment(d2recalc).isAfter(dp2.date)) {
                // console.log('d1 > d2 + e || d1 > d2 + e');
                dp2.inputDate = d2recalc;
                dp2.minDate = d2recalcmin;
            } else {
                // console.log('d1 + e < d2');
                dp2.minDate = d2recalcmin;
            }
            dp2.enforceDateChange();

            if(_self.minDuration && moment(dp2.date).isAfter(d2recalc)) {
                updateMinTime();
            }
        }
    }

    function calcClosestTime(time) {
        var roundedUp = Math.ceil(time.m / t_interval) * t_interval, newTime = (roundedUp) ? moment().minute(roundedUp).format('mm') : '00';
        console.log('newTime:', newTime, 'roundedUp: ',roundedUp);

        return (t_interval === 30 && time.m >= 30 || time.m > 45) ?
            (parseInt(time.h) + 1) + ':' + newTime : time.h + ':' + newTime;
    }

    function calcTimeIndexOffset() {
        // Calculate index based on time min and time interval
        if (t_interval > 1) {
            var offset = (t_interval === 15) ? _self.tmin * 4 : _self.tmin * 2;
            console.log('return: ', tStart.index + offset);
            return tStart.index + offset;
        } else {
            console.log('else return: ', tStart.index + _self.tmin);
            return tStart.index + _self.tmin;
        }
    }

    function validateTimeDuration() {
        console.log('- VALIDATE\n outOfBounds: ',outOfBounds,' t_interval: ',t_interval,' | t1_items:', t1_items.length, ' | t2_items:', t2_items.length);

        if (isToday) {
            updateMinTime();
            // If updateMinTime returns with outOfBounds then return
            if (outOfBounds) return;

            if (_self.equalDates) {
                _self.disableEndPastHours(tNow.index, t1_items);
            } else if(_self.minDuration && moment(dp2.date).isAfter(d2recalc)) {
                _self.resetDisabledTimeValues(t1_items, t2_items);
            } else {
                console.log('-------------<> jsjhvgshgifhguidh <>');
                // _self.enableTimeEndValues(t2_items);
                enableTimeEndValues();
                // disableDropoffPastHours();
            }
            if(tStart.index <= tNow.index) {
                _self.disableEndPastHours(tNow.index, t1_items);
            }
        }
    }

    function calcDateChanged() {
        // DEPRECATED
        // console.log('CALC DATES: initState: ',initState,'\ndp1.inputDate', dp1.inputDate,' | dp1.date: ',dp1.date,' | dp1.minDate',dp1.minDate);
        // console.log('dp2.inputDate', dp2.inputDate,' | dp2.date: ',dp2.date,' | dp2.minDate',dp2.minDate);
        _self.equalDates = dp1.date === dp2.date;

        equal_or_min = !!(_self.equalDates || _self.minDuration);
        console.log(typeof _self.equalDates, typeof _self.minDuration, 'equal_or_min ',equal_or_min);
        isToday = dp1.date === _self.today;

        console.log('> equal_or_min: ',equal_or_min,'calcDateChanged isToday: ',isToday,' _self.initState', _self.initState);

        // If min reservation duration is over 24h then equal dates do not apply
        if(_self.equalDates && !isToday) {
            updateMinTime();
        }

        if(_self.equalDates) {
            if (isToday) {
                validateTimeDuration(); // if today calls updateMinTime
            } else {
                disableDropoffPastHours();
            }
        } else {
            if (isToday) {
                validateTimeDuration(); // if today calls updateMinTime
                // disableDropoffPastHours();
            } else {
                updateMinDate();
                _self.resetDisabledTimeValues(t1_items, t2_items);
            }
        }

    }

    // !CAUTION: Date dividers must remain '/'. TODO Change this in app-datepicker
    if(this.disabledDates.length > 0) {
        this.setDisabledDates(this.disabledDates);
    }

    app._onSelectedDateChanged = function(e) {
        console.log('> _onSelectedDateChanged e: ',e);
        console.log('> _onSelectedDateChanged dp1.inputDate: ',dp1.inputDate,' | dp1.date: ',dp1.date,' | dp1.minDate: ',dp1.minDate);
        console.log('dp2.inputDate: ',dp2.inputDate,' | dp2.date: ',dp2.date,' | dp2.minDate: ',dp2.minDate);

        if(outOfBounds) {
            outOfBounds = !1; return;
        }

        minDdate = getMinDurationDate();

        // start + min >= end
        if(moment(minDdate).isSameOrAfter(dp2.date)) {
            // start + min >= end
            // set end = start + min
            // endMin = end - 1
            if (moment(minDdate).isAfter(dp2.date)) {
                // Update dateEnd
                updateEndDate(minDdate);
            }
            // Disable end hours from time.start
            _self.disableEndPastHours(tStart.index, t2_items);
            // Calc indexes
        } else {
            enableTimeEndValues()
        }

        _self.formatDates();
        app._closeDialog();

        console.log('> _onSelectedDateChanged dp1.inputDate: ',dp1.inputDate,' | dp1.date: ',dp1.date,' | dp1.minDate: ',dp1.minDate);
        console.log('dp2.inputDate: ',dp2.inputDate,' | dp2.date: ',dp2.date,' | dp2.minDate: ',dp2.minDate);
    };

    app._onSelectedTime_1Change = function(_n, _o) {
        tStart.index = _n;
        console.log('--> t1 n o: ',_n, _o, 'tStart.index: ',tStart.index);
        if (_n && equal_or_min) {
            validateTimeDuration();
        }
    };
    app._onSelectedTime_2Change = function(_n, _o) {
        tEnd.index = _n;
        console.log('--> t2 n o: ',_n, _o);
        // if (_n && _self.equalDates &&_n < tStart.index) {
        //     validateTimeDuration();
        // }
    };

    // Set format for date-display wc
    app.formatted = function(v) {
        var date = {
            day: moment(v).format('D'),
            dayw: moment(v).format('dddd'),
            monthYear: moment(v).format('MMM YYYY')
        };
        return date;
    };

    // Set initial states
    initDates();
};

document.addEventListener("DOMContentLoaded", function(event) {
    DateTimePicker.init();

    console.log('DateTimePicker.minDuration ',DateTimePicker.minDuration);
});


// TODO Set listeners to one and the same handler
window.addEventListener('WebComponentsReady', function() {
    console.log('WebComponentsReady, dtpReady: ', dtpReady);
    wcReady = !0;
    if (dtpReady && wcReady) {
        DateTimePicker.datetimepicker();
    }
});
window.addEventListener('datetime-picker-ready', function() {
    console.log("datetime-picker-ready");
    dtpReady = !0;
    if (dtpReady && wcReady) {
        DateTimePicker.datetimepicker();
    }
});
