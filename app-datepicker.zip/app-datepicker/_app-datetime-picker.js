/* Adaptation of component app-datepicker https://www.webcomponents.org/element/motss/app-datepicker/elements/app-datepicker
* TODO
* - Highlight duration
* - Verbals
*/

import '@polymer/polymer/polymer-legacy.js';
import {Polymer} from '@polymer/polymer/lib/legacy/polymer-fn.js';
import {html} from '@polymer/polymer/lib/utils/html-tag.js';
import {dom} from '@polymer/polymer/lib/legacy/polymer.dom.js';

import '@polymer/neon-animation/neon-animations.js';
import '@polymer/paper-menu-button/paper-menu-button.js';
import '@polymer/paper-item/paper-item.js';
import '@polymer/paper-listbox/paper-listbox.js';
import '@polymer/paper-dropdown-menu/paper-dropdown-menu.js';
import './date-display.js';
import {DatePickerBehavior} from './datepicker-behavior.js';
import './app-datepicker.js';
import '../../assets/gomega/reboot-styles.js';
import '../../assets/gomega/grid-styles.js';
import '../../assets/gomega/shared-button-styles.js';
import '../../assets/app-icons.js';

const template = html`
<dom-module id="app-datetime-picker">
    <template strip-whitespace>
        <style include="reboot-styles grid-styles shared-button-styles">
            :host {
                --adp-backdrop-bg: rgba(0,0,0,.2) default;
                --paper-item-min-height: 34px
            }
            #adpBackdrop {
                background-color: var(--adp-backdrop-bg);
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                display: none;
                z-index: 90;
            }
            app-datepicker {
                display: none;
                box-shadow: 0 2px 20px rgba(0,0,0,.2);
                position: absolute;
                /* top: 100%; TODO variable */
                left: 0;
                overflow: hidden;
                z-index: 100;
            }
            app-datepicker[open="true"] { display: block; }
            paper-menu-button {
                padding: 0;
                width: 100%;
            }
            paper-listbox { max-height: 480px; }
            paper-item { cursor: pointer; width: 160px; }
            paper-item.iron-selected:focus:before {
                background-color: #fff;
            }

            .adp-item {
                position: relative;
                flex: 0 0 100%;
                max-width: 100%;
                padding-right: var(--grid-gutter-half, 10px);
                padding-left: var(--grid-gutter-half, 10px);
                @apply --adp-item;
            }
            .btn {
                background: var(--adp-btn-bg);
                color: var(--adp-btn-color);
                text-align: left;
                width: 100%;

                @apply --adp-btn;
            }
            .btn-date {
                @apply --adp-btn-date;
            }
            .btn-time {
                position: relative;
                @apply --adp-btn-time;
            }
            .btn-time::after {
                content: '';
                border-style: solid;
                border-width: 0 1px 1px 0;
                border-color: transparent var(--primary) var(--primary) transparent;
                position: absolute;
                right: 28px;
                top: 50%;
                margin-top: -6px;
                pointer-events: none;
                height: 10px;
                width: 10px;
                -webkit-transform: rotate(45deg);
                -ms-transform: rotate(45deg);
                transform: rotate(45deg);
                z-index: 0;
            }
            .btn-label {
                margin-left: 10px;
                font-weight: bold;
                font-size: 18px;
                display: inline-block;
                vertical-align: middle;
            }

            @media (min-width: 768px) {
                .adp-item {
                    flex-basis: 50%;
                    max-width: 50%;
                }
            }
        </style>
        <div id="adpBackdrop" on-click="_closeDialog"></div>
        <!-- Date & Time 1, Date & Time 2: ! Use of input-date attr caused miscalculation on active month of year change  -->
        <div id="dateTime1" class="adp-item">
            <slot name="label-date-start"></slot>
            <button on-click="_toggleDialog" type="button" class="btn btn-date">
                <date-display date="{{formattedDate_1}}"></date-display>
            </button>
            <app-datepicker
                id="dp1"
                format="yyyy-mm-dd"
                date="{{selectedDate_1}}"
                on-date-changed="_onSelectedDateChanged"
                input-date="{{inputDate}}"
                min-date="{{minDate}}"
                max-date="{{maxDate}}"
                auto-update-date="true"
                disable-days="{{disableDays}}"
                disable-dates="{{disableDates}}"
                no-animation
            ></app-datepicker>

            <paper-menu-button id="time1" on-iron-select="_onTimeChanged" horizontal-offset="[[paperMenuBtnHoffset]]">
                <div slot="dropdown-trigger">
                  <button class="btn btn-time" type="button"><iron-icon icon="app-icons:time" aria-hidden="true"></iron-icon>
                    <span class="btn-label">{{selectedTime_1value}}</span></button>
                </div>
                <paper-listbox slot="dropdown-content" class="dropdown-content dc1" selected="{{selectedTime_1}}" id="plb_1">
                    <template is="dom-repeat" items="[[intervalHours]]" id='t1_list'>
                        <paper-item index$="[[index]]" value$="[[item]]">[[item]]</paper-item>
                    </template>
                </paper-listbox>
            </paper-menu-button>
        </div>
        <div id="dateTime2" class="adp-item">
            <slot name="label-date-end"></slot>
            <button on-click="_toggleDialog" type="button" class="btn btn-date">
                <date-display date="{{formattedDate_2}}"></date-display>
            </button>
            <app-datepicker
                id="dp2"
                format="yyyy-mm-dd"
                date="{{selectedDate_2}}"
                on-date-changed="_onSelectedDateChanged"
                max-date="{{maxDate}}"
                auto-update-date="true"
                disable-days="{{disableDays}}"
                disable-dates="{{disableDates}}"
                no-animation
            ></app-datepicker>

            <paper-menu-button id="time2" on-iron-select="_onTimeChanged" horizontal-offset="[[paperMenuBtnHoffset]]">
                <div slot="dropdown-trigger">
                  <button class="btn btn-time" type="button"><iron-icon icon="app-icons:time" aria-hidden="true"></iron-icon>
                    <span class="btn-label">[[selectedTime_2value]]</span></button>
                </div>
                <paper-listbox slot="dropdown-content" class="dropdown-content dc2" selected="{{selectedTime_2}}" id="plb_2">
                    <template is="dom-repeat" items="[[intervalHours]]" id="t2_list">
                        <paper-item index$="[[index]]" value$="[[item]]">[[item]]</paper-item>
                    </template>
                </paper-listbox>
            </paper-menu-button>
        </div>
    </template>
    `;
template.setAttribute('style', 'display: none;');
document.body.appendChild(template.content);

Polymer({
    is: 'app-datetime-picker',
    behaviors: [DatePickerBehavior],
    //
    properties: {
        timeInterval: {
            type: String,
            value: '00'
        },
        intervalHours: {
            type: Array,
            computed: '_setInterval(timeInterval)'
        },
        paperMenuBtnHoffset: Number,
        selectedDate_1: {
            type: String,
            notify: true
        },
        selectedDate_2: {
            type: String,
            notify: true
        },
        selectedTime_1: {
            type: String,
            notify: true,
            value: '1',
            observer: '_onSelectedTime_1Change'
        },
        selectedTime_2: {
            type: String,
            notify: true,
            value: '2',
            observer: '_onSelectedTime_2Change'
        },
        selectedTime_1value: {
            type: String,
            notify: true,
            value: '00:00',
            computed: '_displayTime(selectedTime_1)'
        },
        selectedTime_2value: {
            type: String,
            notify: true,
            value: '00:00',
            computed: '_displayTime(selectedTime_2)'
        }
    },

    _setInterval: function(str) {
        var arr;
        if(str === '15') {
            arr = ['00','15','30','45'];
        } else if (str === '30') {
            arr = ['00','30'];
        } else {
            arr = ["00"];
        }
        var times = [];
        for (var i = 0; i < 24; i++) {
            for (var j = 0, l = arr.length; j < l; j++) {
                var time = i + ":" + arr[j];
                if (i < 10) {
                    time = "0" + time;
                }
                times.push(time);
            }
        }
        this.set('intervalHours', times);
        return times;
    },
    _onSelectedTime_1Change: function (_n, _o) {
    },
    _onSelectedTime_2Change: function (_n, _o) {
    },
    _displayTime: function (v) {
        return this.intervalHours[v];
    },
    _onTimeChanged: function (e) {},
    getElements: function(el) {
        return dom(this.$[el]).querySelectorAll('paper-item');
    },
    ready: function ready() {
        this.async(function () {
            this.fire("datetime-picker-ready")
        });
    }
});
