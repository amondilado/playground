import {html} from '@polymer/polymer/lib/utils/html-tag.js';

const template = html`
<dom-module id="shared-styles">
<template>
  <style>
    /* dark-theme */
    :host(.dark-theme) {
        background-color: var(--app-datepicker-bg, #424242);
    }
    :host(.dark-theme) iron-selector.selected-fulldate {
        color: var(--app-datepicker-selection-color, #9e9e9e);
        background-color: var(--app-datepicker-selection-bg, #555);
    }
    :host(.dark-theme) .selected-year.iron-selected,
    :host(.dark-theme) .selected-date.iron-selected {
        color: var(--app-datepicker-iron-selected, #f5f5f5);
    }
    :host(.dark-theme) neon-animated-pages.fullcalendar {
        color: var(--app-datepicker-calendar-color, #f5f5f5);
        background-color: var(--app-datepicker-calendar-bg, #424242);
    }
    :host(.dark-theme) .days-of-week {
        color: var(--app-datepicker-weekdays-color, #7c7c7c);
    }
    :host(.dark-theme) div > .days-of-month > .each-days-of-month.chosen-days-of-month {
        color: var(--app-datepicker-selected-day-color, #555);
        background-color: var(--app-datepicker-selected-day-bg, #80cbc4);
    }
    :host(.dark-theme) .days-of-month > .each-days-of-month.is-today {
        color: var(--app-datepicker-today-color, #80cbc4);
    }
    :host(.dark-theme) .days-of-month > .each-days-of-month.is-disabled-day {
        color: var(--app-datepicker-disabled-color, #ffff00);
    }
    :host(.dark-theme) .each-list-of-years.is-selected {
        background-color: var(--app-datepicker-selected-year-bg, rgba(0, 0, 0, 0));
        color: var(--app-datepicker-selected-year-color, #80cbc4);
        font-size: 26px;
        font-weight: 500;
    }
    :host(.dark-theme) paper-icon-button {
        color: var(--app-datepicker-icon-button-color, #ffff00);
        --paper-icon-button-ink-color: var(--app-datepicker-icon-button-ink-color, #212121);
    }
    :host(.dark-theme) ::slotted(paper-button) {
        color: var(--app-datepicker-button-color, #80cbc4);
        --paper-button-ink-color: var(--app-datepicker-button-ink-color, #bcbcbc);
    }
  </style>
  </template>
</dom-module>`;
template.setAttribute('style', 'display: none;');
document.head.appendChild(template.content);