import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '../../assets/app-icons.js';

/** `date-format`
 *
 * @customElement
 * @polymer
 */
class DateDisplay extends PolymerElement {
    static get template() {
        return html`
            <style>
                :host {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    text-align: left;
                }
                * { box-sizing: border-box; }
                iron-icon {
                    --iron-icon-height: var(--df-ic-calendar-width,24px);
                    --iron-icon-width: var(--df-ic-calendar-width,24px);
                }
                .day {
                    font-size: var(--df-day-fontsize,1rem);
                    line-height: 1;
                }
                .dayw, .month-year {
                    flex: 0 0 100%;
                    max-width: 100%;
                }
            </style>
            <span class="day">[[date.day]]</span>
            <span class="date">[[date.dayw]]<br/>[[date.monthYear]]</span>
            <iron-icon icon="app-icons:calendar" aria-hidden="true"></iron-icon>
    `;}
}
window.customElements.define('date-display', DateDisplay);
